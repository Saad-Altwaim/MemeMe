//
//  ViewController.swift
//  Meme_v1
//
//  Created by Saad altwaim on 6/6/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UIImagePickerControllerDelegate,
UINavigationControllerDelegate, UITextFieldDelegate
{
          
    @IBOutlet weak var display: UIImageView!
    let pickerController = UIImagePickerController()
    @IBOutlet weak var Share_Image: UIBarButtonItem!
    @IBOutlet weak var cameraButton: UIBarButtonItem!
    var memedImage: UIImageView!
    @IBOutlet weak var Chose_Image: UIBarButtonItem!
     @IBOutlet weak var Cancelbutton1: UIBarButtonItem!
    @IBOutlet weak var topTxt: UITextField!
    @IBOutlet weak var btmTxt: UITextField!
    // to store the current active textfield
    var activeTextField : UITextField? = nil
    
     struct Meme
    {
        let topTxt: String
        let btmTxt: String
        let display:UIImage!
        let memedImage:UIImage!
    }
    
    func chooseImageFromCameraOrPhoto(source: UIImagePickerController.SourceType) {
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        pickerController.allowsEditing = true
        pickerController.sourceType = source
        present(pickerController, animated: true, completion: nil)
    }
 

    override func viewDidLoad()
     {
       super.viewDidLoad()
        pickerController.delegate  = self
       cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
        func txt(text1 : UITextField)->UITextField
        {
           let  text : UITextField!
            text = text1
            text.delegate = self
            text.defaultTextAttributes = memeTextAttributes
            text.textAlignment = .center
            return text
        }
        txt(text1:topTxt)
        txt(text1:btmTxt)
        
       // navigationController?.setToolbarHidden(false, animated: false)
        self.tabBarController?.tabBar.isHidden = true

         /*
         topTxt.delegate = self
         btmTxt.delegate = self
         topTxt.defaultTextAttributes = memeTextAttributes
         topTxt.textAlignment = .center
         btmTxt.defaultTextAttributes = memeTextAttributes
         btmTxt.textAlignment = .center*/
        
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
 
     }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        subscribeToKeyboardNotification()
         subscribeToKeyboardNotificationH()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        unsubscribeToKeyboardNotification()
    }
    let memeTextAttributes: [NSAttributedString.Key: Any] = [
        NSAttributedString.Key.strokeColor : UIColor.black,
        NSAttributedString.Key.foregroundColor: UIColor.white,
        NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
        NSAttributedString.Key.strokeWidth: -5.1
    ]
    
        @IBAction func pickImage()
        {
            display.image != nil
            chooseImageFromCameraOrPhoto(source: .photoLibrary)
             
           /*
            pickerController.allowsEditing = false
            pickerController.delegate = self
            pickerController.sourceType = .photoLibrary
            present(pickerController, animated: true, completion: nil)
             */
        }
    @IBAction func ShareImage(){
    let image = generateMemedImage()
           let controller = UIActivityViewController(activityItems:[image],applicationActivities:nil)
            self.present(controller,animated:true,completion:nil)
        
        controller.completionWithItemsHandler = { (activityType: UIActivity.ActivityType?, completed:
        Bool, arrayReturnedItems: [Any]?, error: Error?) in
            if completed {
                self.save()
                print("share completed")
                return
            } else {
                print("cancel")
            }
            if let shareError = error {
                print("error while sharing: \(shareError.localizedDescription)")
            }
        }
    }
    
    @IBAction func openCamera() {
        display.image != nil
        pickerController.delegate = self
        
        if UIImagePickerController.isSourceTypeAvailable(.camera)
        {
        chooseImageFromCameraOrPhoto(source: .camera)
        /*
        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
        pickerController.sourceType = .camera
        self.present(pickerController, animated: true, completion: nil)
         */
        }
        else
        {

            let actionSheet1 = UIAlertController(title:" Error", message: "the Camre is not Available", preferredStyle: .actionSheet)
                actionSheet1.addAction(UIAlertAction(title:"Cancel", style: .cancel, handler: nil))
                
                self.present(actionSheet1,animated: true, completion: nil)
            
        }
    }
    @IBAction func Cancelbutton() {
       // display.isHidden = true
        display.image = nil
        print("hi")
        /*
        let actionSheet2 = UIAlertController(title:" Error", message: "the Camre is not Available", preferredStyle: .actionSheet)
        actionSheet2.addAction(UIAlertAction(title:"Cancel", style: .cancel, handler: nil))
        self.present(actionSheet2,animated: true, completion: nil)
        */
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            display.contentMode = .scaleAspectFit
            display.image = pickedImage
            Chose_Image.isEnabled = true
            picker.dismiss(animated: true, completion: nil)
        }
            dismiss(animated: true, completion: nil)
        }
 
     func save() {
              // Create the meme
         let meme = Meme(topTxt: topTxt.text!, btmTxt: btmTxt.text!, display: display.image!, memedImage: generateMemedImage())
        
        // Add it to the memes array in the Application Delegate 
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        appDelegate.memes.append(meme)
      }


    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    @objc func keyboardWillShow(_ notification:Notification)
    {
        self.view.frame.origin.y = -getKeyboardHeight(notification)
        var shouldMoveViewUp = false

        // if active text field is not nil
        if let activeTextField = activeTextField {

          let bottomOfTextField = activeTextField.convert(activeTextField.bounds, to: self.view).maxY;
          
          let topOfKeyboard = view.frame.height - getKeyboardHeight(notification)

          // if the bottom of Textfield is below the top of keyboard, move up
          if bottomOfTextField < topOfKeyboard {
            shouldMoveViewUp = true
          }
        }

        if(shouldMoveViewUp) {
            self.view.frame.origin.y = 0
        }
    }
    @objc func keyboardWillHide(_ notification:Notification)
       {
        self.view.frame.origin.y = 0
       }
    // when user select a textfield, this method will be called
    func textFieldDidBeginEditing(_ textField: UITextField) {
      // set the activeTextField to the selected textfield
      self.activeTextField = textField
        
    }
    func getKeyboardHeight(_ notification :Notification)-> CGFloat{
        let userInfo = notification.userInfo
        let keyboardSize = userInfo?[UIResponder.keyboardFrameEndUserInfoKey]as! NSValue
        
        return keyboardSize.cgRectValue.height
        
    }
    
    func subscribeToKeyboardNotification()
    {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)),
            name: UIResponder.keyboardWillShowNotification, object: nil)
    }
    func subscribeToKeyboardNotificationH(){
       //dismiss(animated: true, completion: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)),
        name: UIResponder.keyboardWillHideNotification, object: nil)
    }


    func unsubscribeToKeyboardNotification()
    {
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification,object: nil)
        dismiss(animated: true, completion: nil)
    }
    // dismiss(animated: true, completion: nil)

    func generateMemedImage() -> UIImage {
        // TODO: Hide toolbar and navbar

           UIGraphicsBeginImageContext(self.view.frame.size)
            view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
            let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
            UIGraphicsEndImageContext()
            // TODO: Show toolbar and navbar
            
            return memedImage
        }

    
}
