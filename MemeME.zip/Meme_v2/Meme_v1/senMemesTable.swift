//
//  senMemesTable.swift
//  Meme_v1
//
//  Created by Saad altwaim on 6/27/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

import UIKit

class senMemesTable: UIViewController {
    /* let appDelegate = UIApplication.shared.delegate as! AppDelegate
     memes = appDelegate.memes//  Ch4 [5] Code for Using a Shared
     */

      // Alternately, a computed property can achieve the same result for code above
       var memes: [ViewController.Meme]! {
       let object = UIApplication.shared.delegate
       let appDelegate = object as! AppDelegate
       return appDelegate.memes
           
       }

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
