//
//  CollectionViewCell.swift
//  Meme_v1
//
//  Created by Saad altwaim on 6/30/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

import UIKit
                     
class CustomMemeCell: UICollectionViewCell {
    
    @IBOutlet weak var memeCell: UIImageView!
}
